【Intel搭載 Mac での利用について】

現在配布されている `OvertimeChecker` アプリは、Apple Silicon (M1/M2/M3) に最適化されています。
Intel 搭載の Mac で起動しない場合は、以下の手順で「Intel用アプリ」を作成してください。

■ 作成手順 (Intel Mac上で行ってください)
1. ターミナルを開きます。
2. このフォルダ（`build_mac.sh` がある場所）に移動します。
   cd /path/to/folder
3. 以下のコマンドを実行します。
   sh build_mac.sh

4. 完了すると `dist` フォルダに新しい `OvertimeChecker` が作成されます。
   これをご利用ください。
